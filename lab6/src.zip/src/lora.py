#!/usr/bin/env python
import time
import serial
import rospy
from std_msgs.msg import String
from geometry_msgs.msg import Twist
from math import pi
from nav_msgs.msg import MapMetaData
from move_base_msgs.msg import MoveBaseActionGoal
from geometry_msgs.msg import PoseWithCovarianceStamped
import numpy as np
import threading
# node initialization
rospy.init_node("robot2_lora",anonymous=True) rate = rospy.Rate(10) # 10hz
time.sleep(1)
pub = rospy.Publisher('mov_key', String, queue_size=20)
pub2 = rospy.Publisher('move_base/goal',MoveBaseActionGoal, queue_size=100) amcl_pose = None # serial initialization
com = serial.Serial(
port= "/dev/ttyUSB0", baudrate= 9600, bytesize= serial.EIGHTBITS, parity= serial.PARITY_NONE, stopbits= serial.STOPBITS_ONE, ) class robot2(): def __init__(self): pass 21
def robot2_lora(self): time1 = time.time() while True: package = "" while True: self.listener()
time2 = time.time() rxd = com.read_all().decode("utf-8")
if len(rxd) > 0: package = package + rxd
if "Rssi= -" in package: rospy.loginfo(package)
# rospy.loginfo(package[16:-13])
#cmd = package[16:-13] cmd = self.get_package_data(package) rospy.loginfo(cmd) robot_num = cmd[0:2]
task = cmd[3:5] mov_cmd = cmd[6:8] rospy.loginfo(robot_num) rospy.loginfo(task)
if robot_num == "02":
if task == "01":
if mov_cmd == "01": pub.publish("i")
print("pub i") elif mov_cmd == "02": pub.publish("o")
print("pub o") elif mov_cmd == "03": pub.publish("j")
print("pub j") elif mov_cmd == "04": pub.publish("l") elif mov_cmd == "05": pub.publish("u") elif mov_cmd == "06": 22
pub.publish(",") elif mov_cmd == "07": pub.publish(".") elif mov_cmd == "08": pub.publish("m") elif mov_cmd == "11": pub.publish("q") elif mov_cmd == "12": pub.publish("z") elif mov_cmd == "13": pub.publish("w") elif mov_cmd == "14": pub.publish("x") elif mov_cmd == "15": pub.publish("e") elif mov_cmd == "16": pub.publish("c") elif mov_cmd == "00": pub.publish("k")
#print(package)
break
if task == "02": rospy.loginfo(self.amcl_pose) rospy.loginfo(str(self.amcl_pose.pose.pose.position.x)[:8]) rospy.loginfo(str(self.amcl_pose.pose.pose.position.y)[:8]) rospy.loginfo(str(self.amcl_pose.pose.pose.position.z)[:8]) self.x = self.amcl_pose.pose.pose.position.x
self.y = self.amcl_pose.pose.pose.position.y x = self.data_process(self.amcl_pose.pose.pose.position.x)
y = self.data_process(self.amcl_pose.pose.pose.position.y)
# rospy.loginfo(self.amcl_pose.pose.pose.position.z[:8]) rospy.loginfo("02"+x+y) str_bytes = ("AT+SEND="+"02"+x+y+"\r\n").encode() com.write(str_bytes)
break
if robot_num == "00" and task == "00": gather_msg = cmd[3:]
#gather_msg = gather_msg[6:] rospy.loginfo("get gather point: "+gather_msg)
23
x_str=gather_msg[6:8]+gather_msg[9:11]+gather_msg[12:14] self.gather_x = float(x_str) / 1000
if gather_msg[3:5] == "00": self.gather_x = -self.gather_x
y_str=gather_msg[18:20]+gather_msg[21:23]+gather_msg[24:26] self.gather_y = float(y_str) / 1000
if gather_msg[15:17] == "00": self.gather_y = -self.gather_y
point1 = np.array([self.x, self.y])
point2 = np.array([self.gather_x, self.gather_y])
L = np.linalg.norm(point1-point2)
R = 0.3
target_x = (R/L)*self.x + (1-R/L)*self.gather_x
target_y = (R/L)*self.y + (1-R/L)*self.gather_y
rospy.loginfo(target_x) rospy.loginfo(target_y) vec = point2-point1
goal = MoveBaseActionGoal()
goal.goal.target_pose.header.frame_id='map' goal.goal.target_pose.pose.position.x= target_x goal.goal.target_pose.pose.position.y= target_y
goal.goal.target_pose.pose.position.z= 0.0
goal.goal.target_pose.pose.orientation.x = 0.0
goal.goal.target_pose.pose.orientation.y = 0.0
goal.goal.target_pose.pose.orientation.z = 0.32
goal.goal.target_pose.pose.orientation.w = 0.0
pub2.publish(goal)
24
def data_process(self,num): num_str=""
if num < 0: num_str=num_str+"00" num = -num
else:num_str=num_str+"11" num = int(num / 0.001) num2 = num
while (1000000 / num2 > 10): num_str=num_str+"0" num2 = num2 * 10
num_str=num_str+str(num) return num_str[:10]
def get_package_data(self,pkg): data = [] num1 = 0
for i in range(len(pkg)):
if pkg[i] == "a" and pkg[i+1] == ":": num1 = i+3
if pkg[i] == "R" and pkg[i+1] == "s": num2 = i-2
data = pkg[num1:num2] return data def get_amcl_pose(self,data): self.amcl_pose = data def listener(self): # The anonymous=True flag means that rospy will choose a unique # name for our 'listener' node so that multiple listeners can # run simultaneously. rospy.Subscriber('amcl_pose', PoseWithCovarianceStamped, self.get_amcl_pose)
if __name__ == "__main__": test = robot2()
test.robot2_lora()